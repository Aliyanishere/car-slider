import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { connect } from "./redux/blockchain/blockchainActions";
import { fetchData } from "./redux/data/dataActions";

// react slick
// Import css files
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";


const truncate = (input, len) =>
  input.length > len ? `${input.substring(0, len)}...` : input;

function App() {
  const dispatch = useDispatch();
  const blockchain = useSelector((state) => state.blockchain);
  const data = useSelector((state) => state.data);
  const [claimingNft, setClaimingNft] = useState(false);
  const [feedback, setFeedback] = useState(`Click buy to mint your NFT.`);
  const [mintAmount, setMintAmount] = useState(1);
  const [CONFIG, SET_CONFIG] = useState({
    CONTRACT_ADDRESS: "",
    SCAN_LINK: "",
    NETWORK: {
      NAME: "",
      SYMBOL: "",
      ID: 0,
    },
    NFT_NAME: "",
    SYMBOL: "",
    MAX_SUPPLY: 1,
    WEI_COST: 0,
    DISPLAY_COST: 0,
    GAS_LIMIT: 0,
    MARKETPLACE: "",
    MARKETPLACE_LINK: "",
    SHOW_BACKGROUND: false,
  });

  const claimNFTs = () => {
    let cost = CONFIG.WEI_COST;
    let gasLimit = CONFIG.GAS_LIMIT;
    let totalCostWei = String(cost * mintAmount);
    let totalGasLimit = String(gasLimit * mintAmount);
    console.log("Cost: ", totalCostWei);
    console.log("Gas limit: ", totalGasLimit);
    setFeedback(`Minting your ${CONFIG.NFT_NAME}...`);
    setClaimingNft(true);
    blockchain.smartContract.methods
      .mint(mintAmount)
      .send({
        gasLimit: String(totalGasLimit),
        to: CONFIG.CONTRACT_ADDRESS,
        from: blockchain.account,
        value: totalCostWei,
      })
      .once("error", (err) => {
        console.log(err);
        setFeedback("Sorry, something went wrong please try again later.");
        setClaimingNft(false);
      })
      .then((receipt) => {
        console.log(receipt);
        setFeedback(
          `WOW, the ${CONFIG.NFT_NAME} is yours! go visit Opensea.io to view it.`
        );
        setClaimingNft(false);
        dispatch(fetchData(blockchain.account));
      });
  };

  const decrementMintAmount = () => {
    let newMintAmount = mintAmount - 1;
    if (newMintAmount < 1) {
      newMintAmount = 1;
    }
    setMintAmount(newMintAmount);
  };

  const incrementMintAmount = () => {
    let newMintAmount = mintAmount + 1;
    if (newMintAmount > 2) {
      newMintAmount = 2;
    }
    setMintAmount(newMintAmount);
  };

  const getData = () => {
    if (blockchain.account !== "" && blockchain.smartContract !== null) {
      dispatch(fetchData(blockchain.account));
    }
  };

  const getConfig = async () => {
    const configResponse = await fetch("/config/config.json", {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });
    const config = await configResponse.json();
    SET_CONFIG(config);
  };

  useEffect(() => {
    getConfig();
  }, []);

  useEffect(() => {
    getData();

    document.querySelector('.ws-prev').onclick = () => {
      document.querySelector('.slick-prev').click()
    }
    document.querySelector('.ws-next').onclick = () => {
      document.querySelector('.slick-next').click()
    }

  }, [blockchain.account]);


  const settings = {
    centerMode: true,
    centerPadding: '0px',
    dots: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 7,
    slidesToScroll: 1,
    autoplay: false,
    responsive: [
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1
        }
      }]
  };


  const [modal1, setmodal1] = useState(0)




  return (

    <>
    { modal1 == 1 && 
      <div className="modal-1">
        <div className="inner">
          <div className="modal-head">
            <span onClick={()=>setmodal1(0)}>X</span>
          </div>
          <div className="p-3 d-flex justify-content-center align-items-center flex-column">
            <h5>Roadmap</h5>
            <p>
              Minting
              We plan to mint by the 10th of January 2022. A minting rally will be hosted where physical scannable QR codes will be placed around the globe. First person to scan the code receives an NFT.
            </p>
            <p>
              10% sold
              At 10% sales, we airdrop 2 Legendary series NFTs to random holders of the Midnight Club.
            </p>
            <p>
              30% sold
              -At 30% sales, we announce the Secret discord thread where only holders can chat and receive exclusive information about the project’s progress and events.
            </p>
            <p>
              60% sold
              At 60% percent sold, a new THE CAR GODS mini-series is released comprising of 20 legendary cars. 15 NFT’S are airdropped to lucky holders. 5 NFT’s are auctioned for charity, the charity being decided by the Discord Community.
            </p>
            <p>
              80% sold
              -At 80% percent sold, coordinates and dates for the midnight club’s first social event are announced. Only holders are invited. -Digital Concours D’elegance is held, the prize for the winner: 1-2 ETH and a TROPHY implemented into the winning cars nft.
            </p>
            <p>
              100% sold
              -At 100% sales, the Mint Date of the DAWN CLUB is announced and EACH HOLDER of the Midnight club receives an item from the sequel collection. Another Rally is announced for holders only.
            </p>
            <p>
              AFTERSALES:
              -exploration of Metaverse implementation, possibly sandbox game usage. - possible racing/betting game implementation.
            </p>
          </div>
        </div>
      </div>

    }


      <nav className="d-flex  px-lg-5 px-2 align-items-center justify-content-between ">
        <div className="d-flex align-items-center col justify-content-lg-start justify-content-around">
          <span className="px-lg-4 px-0 py-4">About</span>
          <span className="px-lg-4 px-0 py-4" onClick={()=>setmodal1(1)}>Roadmap</span>
        </div>
        <div className="d-flex align-items-center col justify-content-lg-end justify-content-around">
          <span className="px-lg-4 px-0 py-4">Connnect Metamask</span>
          <span className="px-lg-4 px-0 py-4">Buy NFT</span>
        </div>
      </nav>

      <div className="d-flex justify-content-center">
        <img src="config/images/logo.png" className="logo" alt="" />
      </div>


      <Slider {...settings} className="car-slider">
        <div className="car-slide">
          <img src="config/images/car-1.png" alt="" />
        </div>
        <div className="car-slide">
          <img src="config/images/car-2.png" alt="" />
        </div>
        <div className="car-slide">
          <img src="config/images/car-3.png" alt="" />
        </div>
        <div className="car-slide">
          <img src="config/images/car-4.png" alt="" />
        </div>
        <div className="car-slide">
          <img src="config/images/car-1.png" alt="" />
        </div>
        <div className="car-slide">
          <img src="config/images/car-2.png" alt="" />
        </div>
        <div className="car-slide">
          <img src="config/images/car-3.png" alt="" />
        </div>
        <div className="car-slide">
          <img src="config/images/car-4.png" alt="" />
        </div>
      </Slider>

      <div className="d-flex w-100 align-items-center justify-content-center ws-controls">
        <img src="config/images/left.png" className="ws-arrow ws-prev " alt="" />
        <img src="config/images/button.png" className="ws-btn mx-3"
          onClick={(e) => {
            e.preventDefault();
            dispatch(connect());
            getData();
          }}
          alt="" />
        <img src="config/images/right.png" className="ws-arrow ws-next " alt="" />
      </div>
      <div className="d-flex w-100 align-items-center justify-content-center fw-500 py-4">
        <small>Legendary collection (2000 UNIQUES)</small>
      </div>
    </>


    // Privous Code 

    // <s.Screen>
    //   <s.Container
    //     flex={1}
    //     ai={"center"}
    //     style={{ padding: 24, backgroundColor: "var(--primary)" }}
    //     image={CONFIG.SHOW_BACKGROUND ? "/config/images/bg.png" : null}
    //   >
    //     <StyledLogo alt={"logo"} src={"/config/images/logo.png"} />
    //     <s.SpacerSmall />
    //     <ResponsiveWrapper flex={1} style={{ padding: 24 }} test>
    //       <s.Container flex={1} jc={"center"} ai={"center"}>
    //         <StyledImg alt={"example"} src={"/config/images/example.gif"} />
    //       </s.Container>
    //       <s.SpacerLarge />
    //       <s.Container
    //         flex={2}
    //         jc={"center"}
    //         ai={"center"}
    //         style={{
    //           backgroundColor: "var(--accent)",
    //           padding: 24,
    //           borderRadius: 24,
    //           border: "4px dashed var(--secondary)",
    //           boxShadow: "0px 5px 11px 2px rgba(0,0,0,0.7)",
    //         }}
    //       >
    //         <s.TextTitle
    //           style={{
    //             textAlign: "center",
    //             fontSize: 50,
    //             fontWeight: "bold",
    //             color: "var(--accent-text)",
    //           }}
    //         >
    //           {data.totalSupply} / {CONFIG.MAX_SUPPLY}
    //         </s.TextTitle>
    //         <s.TextDescription
    //           style={{
    //             textAlign: "center",
    //             color: "var(--primary-text)",
    //           }}
    //         >
    //           <StyledLink target={"_blank"} href={CONFIG.SCAN_LINK}>
    //             {truncate(CONFIG.CONTRACT_ADDRESS, 15)}
    //           </StyledLink>
    //         </s.TextDescription>
    //         <s.SpacerSmall />
    //         {Number(data.totalSupply) >= CONFIG.MAX_SUPPLY ? (
    //           <>
    //             <s.TextTitle
    //               style={{ textAlign: "center", color: "var(--accent-text)" }}
    //             >
    //               The sale has ended.
    //             </s.TextTitle>
    //             <s.TextDescription
    //               style={{ textAlign: "center", color: "var(--accent-text)" }}
    //             >
    //               You can still find {CONFIG.NFT_NAME} on
    //             </s.TextDescription>
    //             <s.SpacerSmall />
    //             <StyledLink target={"_blank"} href={CONFIG.MARKETPLACE_LINK}>
    //               {CONFIG.MARKETPLACE}
    //             </StyledLink>
    //           </>
    //         ) : (
    //           <>
    //             <s.TextTitle
    //               style={{ textAlign: "center", color: "var(--accent-text)" }}
    //             >
    //               1 {CONFIG.SYMBOL} costs {CONFIG.DISPLAY_COST}{" "}
    //               {CONFIG.NETWORK.SYMBOL}.
    //             </s.TextTitle>
    //             <s.SpacerXSmall />
    //             <s.TextDescription
    //               style={{ textAlign: "center", color: "var(--accent-text)" }}
    //             >
    //               Excluding gas fees.
    //             </s.TextDescription>
    //             <s.SpacerSmall />
    //             {blockchain.account === "" ||
    //             blockchain.smartContract === null ? (
    //               <s.Container ai={"center"} jc={"center"}>
    //                 <s.TextDescription
    //                   style={{
    //                     textAlign: "center",
    //                     color: "var(--accent-text)",
    //                   }}
    //                 >
    //                   Connect to the {CONFIG.NETWORK.NAME} network
    //                 </s.TextDescription>
    //                 <s.SpacerSmall />
    //                 <StyledButton
    //                   onClick={(e) => {
    //                     e.preventDefault();
    //                     dispatch(connect());
    //                     getData();
    //                   }}
    //                 >
    //                   CONNECT
    //                 </StyledButton>
    //                 {blockchain.errorMsg !== "" ? (
    //                   <>
    //                     <s.SpacerSmall />
    //                     <s.TextDescription
    //                       style={{
    //                         textAlign: "center",
    //                         color: "var(--accent-text)",
    //                       }}
    //                     >
    //                       {blockchain.errorMsg}
    //                     </s.TextDescription>
    //                   </>
    //                 ) : null}
    //               </s.Container>
    //             ) : (
    //               <>
    //                 <s.TextDescription
    //                   style={{
    //                     textAlign: "center",
    //                     color: "var(--accent-text)",
    //                   }}
    //                 >
    //                   {feedback}
    //                 </s.TextDescription>
    //                 <s.SpacerMedium />
    //                 <s.Container ai={"center"} jc={"center"} fd={"row"}>
    //                   <StyledRoundButton
    //                     style={{ lineHeight: 0.4 }}
    //                     disabled={claimingNft ? 1 : 0}
    //                     onClick={(e) => {
    //                       e.preventDefault();
    //                       decrementMintAmount();
    //                     }}
    //                   >
    //                     -
    //                   </StyledRoundButton>
    //                   <s.SpacerMedium />
    //                   <s.TextDescription
    //                     style={{
    //                       textAlign: "center",
    //                       color: "var(--accent-text)",
    //                     }}
    //                   >
    //                     {mintAmount}
    //                   </s.TextDescription>
    //                   <s.SpacerMedium />
    //                   <StyledRoundButton
    //                     disabled={claimingNft ? 1 : 0}
    //                     onClick={(e) => {
    //                       e.preventDefault();
    //                       incrementMintAmount();
    //                     }}
    //                   >
    //                     +
    //                   </StyledRoundButton>
    //                 </s.Container>
    //                 <s.SpacerSmall />
    //                 <s.Container ai={"center"} jc={"center"} fd={"row"}>
    //                   <StyledButton
    //                     disabled={claimingNft ? 1 : 0}
    //                     onClick={(e) => {
    //                       e.preventDefault();
    //                       claimNFTs();
    //                       getData();
    //                     }}
    //                   >
    //                     {claimingNft ? "BUSY" : "BUY"}
    //                   </StyledButton>
    //                 </s.Container>
    //               </>
    //             )}
    //           </>
    //         )}
    //         <s.SpacerMedium />
    //       </s.Container>
    //       <s.SpacerLarge />
    //       <s.Container flex={1} jc={"center"} ai={"center"}>
    //         <StyledImg
    //           alt={"example"}
    //           src={"/config/images/example.gif"}
    //           style={{ transform: "scaleX(-1)" }}
    //         />
    //       </s.Container>
    //     </ResponsiveWrapper>
    //     <s.SpacerMedium />
    //     <s.Container jc={"center"} ai={"center"} style={{ width: "70%" }}>
    //       <s.TextDescription
    //         style={{
    //           textAlign: "center",
    //           color: "var(--primary-text)",
    //         }}
    //       >
    //         Please make sure you are connected to the right network (
    //         {CONFIG.NETWORK.NAME} Mainnet) and the correct address. Please note:
    //         Once you make the purchase, you cannot undo this action.
    //       </s.TextDescription>
    //       <s.SpacerSmall />
    //       <s.TextDescription
    //         style={{
    //           textAlign: "center",
    //           color: "var(--primary-text)",
    //         }}
    //       >
    //         We have set the gas limit to {CONFIG.GAS_LIMIT} for the contract to
    //         successfully mint your NFT. We recommend that you don't lower the
    //         gas limit.
    //       </s.TextDescription>
    //     </s.Container>
    //   </s.Container>
    // </s.Screen>
  );
}

export default App;
